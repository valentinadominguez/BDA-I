import json
from rest_framework import generics
from .models import Resume
from .serializers import ResumeSerializer
from rest_framework.permissions import IsAuthenticated

class ResumesApiView(generics.ListAPIView):
    queryset = Resume.objects.all().order_by('-id')
    serializer_class = ResumeSerializer
    permission_classes = (IsAuthenticated,)