from django.urls import path
from .views import ResumesApiView

urlpatterns = [
    path('resumes/', ResumesApiView.as_view())
]