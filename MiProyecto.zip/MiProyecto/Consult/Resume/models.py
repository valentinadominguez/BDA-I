from django.db import models
from Company.models import Company

class Resume(models.Model):
    company = models.ForeignKey(Company, on_delete=models.DO_NOTHING)
    sales = models.IntegerField()
    lost = models.IntegerField()
    earnings = models.DecimalField(max_digits=100, decimal_places=2)
    state = models.CharField(max_length=255)