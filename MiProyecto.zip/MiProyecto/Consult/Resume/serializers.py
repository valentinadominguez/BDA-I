from rest_framework import serializers
from Company.serializers import CompanySerializer
from .models import Resume

class ResumeSerializer(serializers.ModelSerializer):
    company = CompanySerializer()

    class Meta:
        model = Resume
        fields = ('company', 'sales', 'lost', 'earnings', 'state')