from rest_framework.views import APIView
from rest_framework.views import status
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth.models import User
from django.shortcuts import render

def Index(request):
    context = {}

    return render(request, "index.html", context)

def Board(request):
    context = {}

    return render(request, "board.html", context)

class LoginView(APIView):
    authentication_classes = ()
    permission_classes = ()

    def post(self, request, format=None):
        try:
            username = request.data.get('username', None)
            password = request.data.get('password', None)
            
            if not username:
                return Response(
                    data={
                        'message': 'Username cannot be empty.'
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            if not password:
                return Response(
                    data={
                        'message': 'Password cannot be empty.'
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            if User.objects.filter(username=username).exists():
                user = User.objects.get(username=username)

                if user.check_password(password):
                    token, created = Token.objects.get_or_create(user=user)
                    
                    return Response(
                        data={
                            'user': {
                                'token': token.key
                            }
                        },
                        status=status.HTTP_200_OK
                    )
                else:
                    return Response(
                        data={
                            'message': 'Invalid password.'
                        },
                        status=status.HTTP_401_UNAUTHORIZED
                    )
            else:
                return Response(
                    data={
                        'message': 'Invalid username.'
                    },
                    status=status.HTTP_404_NOT_FOUND
                )

            return Response(status=201)
        
        except Exception as e:
            print(str(e))

            return Response(
                data={
                    'message': 'Internal error login.'
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
