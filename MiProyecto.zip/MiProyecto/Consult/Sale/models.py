from django.db import models
from Company.models import Company

class Sale(models.Model):
    company = models.ForeignKey(Company, on_delete=models.DO_NOTHING)
    amount = models.DecimalField(max_digits=100, decimal_places=2)