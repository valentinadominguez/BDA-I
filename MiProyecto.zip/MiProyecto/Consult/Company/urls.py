from django.urls import path
from .views import CompanySalesApi

urlpatterns = [
     path('company/sales/', CompanySalesApi),
]