from django.shortcuts import render
from Company.models import Company
from Sale.models import Sale
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.views import status
from django.db.models import Sum
from rest_framework.permissions import IsAuthenticated

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def CompanySalesApi(request):
    try:
        companies = Company.objects.all()
        
        companiesInfo = []

        for company in companies:
            companiesInfo.append({
                'id': company.id,
                'name': company.business_name,
                'salesCount': Sale.objects.filter(company=company).count(),
                'salesAmount': Sale.objects.filter(company=company).aggregate(Sum('amount'))
            })

        return Response(
            data=companiesInfo,
            status=200
        )

    except Exception as e:
        print(str(e))
        return Response(
            data={
                'message': 'Ocurrió un error un error recuperando la información.'
            },
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )