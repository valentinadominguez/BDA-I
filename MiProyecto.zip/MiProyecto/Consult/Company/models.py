from django.db import models

class Company(models.Model):
    business_name = models.CharField(max_length=255)